#!/usr/bin/env python3
"""Create a photo-first 4:3 display crop from a customer screenshot.

The original screenshot remains untouched. Candidate windows are scored for
photographic texture and colour diversity so social captions and text slides do
not become a place card's main image.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
from pathlib import Path


DEFAULT_ASPECT = 4 / 3
DEFAULT_MIN_PHOTO_SCORE = 0.45
ROLLBACK_STALE_SECONDS = 60 * 60
ROLLBACK_REMOVE_ATTEMPTS = 3


def windows_current_user_sid() -> str:
    result = subprocess.run(
        ["whoami", "/user", "/fo", "csv", "/nh"],
        capture_output=True, text=True, timeout=15, check=False,
    )
    if result.returncode != 0:
        raise PermissionError("PRIVATE_PERMISSION_ENFORCEMENT_FAILED")
    try:
        row = next(csv.reader([result.stdout.strip()]))
    except (csv.Error, StopIteration) as error:
        raise PermissionError("PRIVATE_PERMISSION_ENFORCEMENT_FAILED") from error
    sid = (row[-1] if row else "").strip()
    if not re.fullmatch(r"S-1-(?:\d+-){1,14}\d+", sid, re.IGNORECASE):
        raise PermissionError("PRIVATE_PERMISSION_ENFORCEMENT_FAILED")
    return sid


def apply_and_verify_windows_private_acl(path: Path, sid: str, directory: bool = False) -> bool:
    powershell = shutil.which("powershell.exe") or shutil.which("powershell") or shutil.which("pwsh")
    if not powershell:
        return False
    script = r"""
param([string]$Target, [string]$ExpectedSid, [string]$DirectoryFlag)
$ErrorActionPreference = 'Stop'
$acl = Get-Acl -LiteralPath $Target
$acl.SetAccessRuleProtection($true, $false)
foreach ($existing in @($acl.Access)) { [void]$acl.RemoveAccessRuleSpecific($existing) }
$identity = [System.Security.Principal.SecurityIdentifier]::new($ExpectedSid)
if ($DirectoryFlag -eq 'true') {
  $inheritance = [System.Security.AccessControl.InheritanceFlags]'ContainerInherit, ObjectInherit'
  $propagation = [System.Security.AccessControl.PropagationFlags]::None
  $newRule = [System.Security.AccessControl.FileSystemAccessRule]::new($identity, 'FullControl', $inheritance, $propagation, 'Allow')
} else {
  $newRule = [System.Security.AccessControl.FileSystemAccessRule]::new($identity, 'FullControl', 'Allow')
}
[void]$acl.AddAccessRule($newRule)
Set-Acl -LiteralPath $Target -AclObject $acl
$acl = Get-Acl -LiteralPath $Target
$rules = @($acl.Access)
if (-not $acl.AreAccessRulesProtected -or $rules.Count -ne 1) { exit 41 }
$rule = $rules[0]
$ruleSid = $rule.IdentityReference.Translate([System.Security.Principal.SecurityIdentifier]).Value
$full = [System.Security.AccessControl.FileSystemRights]::FullControl
$hasFull = (([int]$rule.FileSystemRights -band [int]$full) -eq [int]$full)
if ($ruleSid -ne $ExpectedSid -or $rule.AccessControlType -ne 'Allow' -or -not $hasFull) { exit 42 }
"""
    result = subprocess.run(
        [
            powershell, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
            "-Command", f"& {{ {script} }}", str(path), sid, str(bool(directory)).lower(),
        ],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        timeout=30, check=False,
    )
    return result.returncode == 0


def restrict_path_to_current_user(path: Path, directory: bool = False) -> None:
    if sys.platform.startswith("win"):
        sid = windows_current_user_sid()
        grant = f"*{sid}:(OI)(CI)F" if directory else f"*{sid}:F"
        try:
            result = subprocess.run(
                ["icacls", str(path), "/inheritance:r", "/grant:r", grant],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                timeout=30, check=False,
            )
        except (OSError, subprocess.SubprocessError) as error:
            raise PermissionError("PRIVATE_PERMISSION_ENFORCEMENT_FAILED") from error
        if result.returncode != 0 or not apply_and_verify_windows_private_acl(path, sid, directory):
            raise PermissionError("PRIVATE_PERMISSION_ENFORCEMENT_FAILED")
        return
    expected = 0o700 if directory else 0o600
    try:
        path.chmod(expected)
        actual = stat.S_IMODE(path.stat().st_mode)
    except OSError as error:
        raise PermissionError("PRIVATE_PERMISSION_ENFORCEMENT_FAILED") from error
    if actual != expected:
        raise PermissionError("PRIVATE_PERMISSION_ENFORCEMENT_FAILED")


def fsync_directory(path: Path) -> None:
    try:
        descriptor = os.open(str(path), os.O_RDONLY)
    except OSError:
        return
    try:
        os.fsync(descriptor)
    except OSError:
        pass
    finally:
        os.close(descriptor)


def secure_remove_rollback(path: Path) -> None:
    """Remove a rollback image; scrub its contents before failing closed."""
    if not path.exists() and not path.is_symlink():
        return
    if path.is_symlink():
        try:
            path.unlink()
            return
        except OSError as error:
            raise PermissionError("PRIVATE_ROLLBACK_CLEANUP_FAILED") from error
    restrict_path_to_current_user(path)
    last_error = None
    for _ in range(ROLLBACK_REMOVE_ATTEMPTS):
        try:
            path.unlink()
            return
        except OSError as error:
            last_error = error
    try:
        with path.open("r+b", buffering=0) as handle:
            handle.truncate(0)
            os.fsync(handle.fileno())
        restrict_path_to_current_user(path)
    except OSError as error:
        raise PermissionError("PRIVATE_ROLLBACK_CLEANUP_FAILED") from error
    for _ in range(ROLLBACK_REMOVE_ATTEMPTS):
        try:
            path.unlink()
            return
        except OSError as error:
            last_error = error
    raise PermissionError("PRIVATE_ROLLBACK_CLEANUP_FAILED") from last_error


def cleanup_stale_rollbacks(parent: Path, target_name: str) -> None:
    """Clean private, target-specific rollback files old enough not to be active."""
    prefix = f".{target_name}."
    now = time.time()
    for candidate in parent.iterdir():
        if not candidate.name.startswith(prefix) or not candidate.name.endswith(".rollback"):
            continue
        if candidate.is_symlink():
            secure_remove_rollback(candidate)
            continue
        restrict_path_to_current_user(candidate)
        try:
            age = now - candidate.stat().st_mtime
        except OSError as error:
            raise PermissionError("PRIVATE_ROLLBACK_CLEANUP_FAILED") from error
        if age >= ROLLBACK_STALE_SECONDS:
            secure_remove_rollback(candidate)


def cli_locale() -> str:
    for index, value in enumerate(sys.argv[1:]):
        if value == "--locale" and index + 2 <= len(sys.argv[1:]):
            return "en-US" if sys.argv[1:][index + 1].lower().startswith("en") else "zh-CN"
    return "zh-CN"


class LocalizedArgumentParser(argparse.ArgumentParser):
    def error(self, message: str) -> None:
        locale = cli_locale()
        text = (
            "Image preparation arguments are missing or invalid. Check the help text and retry."
            if locale == "en-US"
            else "图片处理参数缺失或格式不正确，请按帮助中的参数重试。"
        )
        self.exit(2, json.dumps({"code": "ARGUMENT_ERROR", "message": text}, ensure_ascii=False) + "\n")


def parse_aspect(value: str) -> float:
    raw = str(value).strip()
    if ":" in raw:
        left, right = raw.split(":", 1)
        aspect = float(left) / float(right)
    else:
        aspect = float(raw)
    if not math.isfinite(aspect) or aspect <= 0:
        raise argparse.ArgumentTypeError("target aspect must be positive")
    return aspect


def evenly_spaced(limit: int, count: int = 9) -> list[int]:
    if limit <= 0:
        return [0]
    return sorted({round(limit * index / (count - 1)) for index in range(count)})


def candidate_boxes(width: int, height: int, aspect: float) -> list[tuple[int, int, int, int]]:
    max_width = min(width, round(height * aspect))
    boxes: set[tuple[int, int, int, int]] = set()
    for scale in (1.0, 0.84, 0.68, 0.55):
        crop_width = max(64, min(width, round(max_width * scale)))
        crop_height = max(48, min(height, round(crop_width / aspect)))
        crop_width = max(1, min(width, round(crop_height * aspect)))
        for left in evenly_spaced(width - crop_width, 7):
            for top in evenly_spaced(height - crop_height, 11):
                boxes.add((left, top, left + crop_width, top + crop_height))
    return sorted(boxes)


def photographic_score(image) -> float:
    from PIL import ImageFilter, ImageStat

    sample = image.convert("RGB")
    sample.thumbnail((128, 96))
    pixel_count = max(1, sample.width * sample.height)

    quantized = sample.quantize(colors=24)
    palette_counts = [
        count for count, _colour in (quantized.getcolors(pixel_count) or [])
    ]
    dominant_share = max(palette_counts, default=pixel_count) / pixel_count
    top_four_share = sum(sorted(palette_counts, reverse=True)[:4]) / pixel_count
    diversity = min(1.0, max(0.0, (1.0 - dominant_share) / 0.70))

    gray = sample.convert("L")
    entropy = min(1.0, gray.entropy() / 7.5)
    contrast = min(1.0, ImageStat.Stat(gray).stddev[0] / 64.0)
    saturation_channel = sample.convert("HSV").getchannel("S")
    saturation = min(1.0, ImageStat.Stat(saturation_channel).mean[0] / 96.0)
    edge_image = gray.filter(ImageFilter.FIND_EDGES)
    edge_strength = min(1.0, ImageStat.Stat(edge_image).mean[0] / 48.0)
    rgb_reader = getattr(sample, "get_flattened_data", sample.getdata)
    rgb_pixels = list(rgb_reader())
    neutral_share = sum(max(pixel) - min(pixel) < 12 for pixel in rgb_pixels) / pixel_count
    black_or_white_share = sum(
        max(pixel) < 45 or min(pixel) > 225 for pixel in rgb_pixels
    ) / pixel_count
    edge_reader = getattr(edge_image, "get_flattened_data", edge_image.getdata)
    edge_pixels = list(edge_reader())
    row_means = [
        sum(edge_pixels[offset:offset + sample.width]) / sample.width
        for offset in range(0, len(edge_pixels), sample.width)
    ]
    row_mean = sum(row_means) / max(1, len(row_means))
    row_variance = sum((value - row_mean) ** 2 for value in row_means) / max(1, len(row_means))
    row_edge_cv = math.sqrt(row_variance) / max(1.0, row_mean)

    score = (
        0.30 * diversity
        + 0.20 * entropy
        + 0.18 * contrast
        + 0.20 * saturation
        + 0.12 * edge_strength
    )
    if dominant_share > 0.55:
        score -= (dominant_share - 0.55) * 0.90
    if saturation < 0.04 and dominant_share > 0.45:
        score -= 0.10
    if top_four_share > 0.48:
        score -= min(0.55, (top_four_share - 0.48) / 0.52 * 0.55)
    if neutral_share > 0.58:
        neutral_penalty = (neutral_share - 0.58) / 0.42
        score -= min(0.72, neutral_penalty * min(1.0, black_or_white_share / 0.45) * 0.72)
    if row_edge_cv > 0.65:
        score -= min(0.30, (row_edge_cv - 0.65) * 0.65)
    return max(0.0, min(1.0, score))


def best_crop(source, aspect: float) -> tuple[tuple[int, int, int, int], float]:
    width, height = source.size
    best_box = (0, 0, width, height)
    best_score = -1.0
    for box in candidate_boxes(width, height, aspect):
        score = photographic_score(source.crop(box))
        # A small upper-screen preference breaks near-ties without hard-coding
        # a platform-specific y offset. Users may have scrolled before capture.
        centre_x = (box[0] + box[2]) / 2 / width
        centre_y = (box[1] + box[3]) / 2 / height
        score += max(0.0, 0.05 * (1.0 - abs(centre_x - 0.5) * 2.0))
        score += max(0.0, 0.02 * (1.0 - centre_y))
        area_ratio = ((box[2] - box[0]) * (box[3] - box[1])) / (width * height)
        score += 0.04 * math.sqrt(area_ratio)
        if score > best_score:
            best_box = box
            best_score = score
    return best_box, max(0.0, min(1.0, best_score))


def prepare_display_image(
    input_path: str,
    output_path: str,
    aspect: float = DEFAULT_ASPECT,
    min_photo_score: float = DEFAULT_MIN_PHOTO_SCORE,
) -> dict[str, object]:
    try:
        from PIL import Image
    except ImportError as exc:
        raise RuntimeError("PILLOW_REQUIRED") from exc

    with Image.open(input_path) as opened:
        source = opened.convert("RGB")
    width, height = source.size
    box, score = best_crop(source, aspect)
    cropped = source.crop(box)
    target = Path(output_path)
    target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    restrict_path_to_current_user(target.parent, directory=True)
    cleanup_stale_rollbacks(target.parent, target.name)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{target.name}.", suffix=".tmp", dir=str(target.parent)
    )
    os.close(descriptor)
    temporary = Path(temporary_name)
    replaced = False
    backup = target.parent / f".{target.name}.{os.urandom(12).hex()}.rollback"
    backup_moved = False
    committed = False
    try:
        cropped.save(temporary, "JPEG", quality=90, optimize=True)
        with temporary.open("rb") as handle:
            os.fsync(handle.fileno())
        restrict_path_to_current_user(temporary)
        if target.exists():
            os.replace(target, backup)
            backup_moved = True
            restrict_path_to_current_user(backup)
        os.replace(temporary, target)
        replaced = True
        restrict_path_to_current_user(target)
        fsync_directory(target.parent)
        committed = True
        if backup_moved and backup.exists():
            secure_remove_rollback(backup)
            backup_moved = False
        fsync_directory(target.parent)
    except Exception:
        temporary.unlink(missing_ok=True)
        if not committed:
            if replaced:
                target.unlink(missing_ok=True)
            if backup_moved and backup.exists():
                os.replace(backup, target)
                backup_moved = False
        fsync_directory(target.parent)
        raise
    photo_rich = score >= min_photo_score
    return {
        "output": str(target),
        "sourceSize": {"width": width, "height": height},
        "cropBox": {
            "x": box[0],
            "y": box[1],
            "width": box[2] - box[0],
            "height": box[3] - box[1],
        },
        "targetAspect": round(aspect, 6),
        "photoScore": round(score, 4),
        "photoRich": photo_rich,
        "strategy": "photo-rich-window" if photo_rich else "text-dominant-fallback",
    }


def main() -> int:
    parser = LocalizedArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--target-aspect", type=parse_aspect, default=DEFAULT_ASPECT)
    parser.add_argument("--min-photo-score", type=float, default=DEFAULT_MIN_PHOTO_SCORE)
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--locale", choices=("zh-CN", "en-US", "en"), default="zh-CN")
    args = parser.parse_args()
    try:
        metadata = prepare_display_image(
            args.input,
            args.output,
            aspect=args.target_aspect,
            min_photo_score=max(0.0, min(1.0, args.min_photo_score)),
        )
    except (OSError, RuntimeError, ValueError) as error:
        locale = "en-US" if args.locale.startswith("en") else "zh-CN"
        code = "PILLOW_REQUIRED" if str(error) == "PILLOW_REQUIRED" else "IMAGE_PREPARATION_FAILED"
        messages = {
            "zh-CN": {
                "PILLOW_REQUIRED": "缺少 Pillow，无法生成确定性的展示裁切图。",
                "IMAGE_PREPARATION_FAILED": "图片读取或裁切失败，请检查文件格式、路径和权限。",
            },
            "en-US": {
                "PILLOW_REQUIRED": "Pillow is required to create a deterministic display crop.",
                "IMAGE_PREPARATION_FAILED": "The image could not be read or cropped. Check its format, path and permissions.",
            },
        }
        print(json.dumps({"code": code, "message": messages[locale][code]}, ensure_ascii=False), file=sys.stderr)
        return 1
    print(json.dumps(metadata, ensure_ascii=False) if args.json else metadata["output"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
