# 来源、系统与访问能力

## 系统边界

- macOS 与 Windows 是正式目标；首次使用必须运行 doctor。
- Python 3.9+、Pillow、Node.js 18+ 是核心依赖。
- Windows 完整 OCR 需要 Tesseract、`eng` 和 `chi_sim`/`chi_tra` 至少一个。
- macOS 优先 Vision OCR，可降级到 Tesseract。
- FFmpeg/FFprobe 只影响视频自动拆帧；缺失时收关键截图。
- PowerShell 5.1 脚本源保持 ASCII-safe，运行时从 UTF-8 配置读取版本；会话设置 `PYTHONUTF8=1` 与 `PYTHONIOENCODING=utf-8`。

本地 macOS 测试和 PowerShell 静态检查不能替代真实 Windows runner。没有远程上传授权时，明确把真实 Windows 复验列为阻塞项。

## `accessLevel`

- `submitted`：顾客直接提交的文字。
- `local_only`：本地截图、视频或保存页。
- `public_readable`：本轮实际读取的公开 HTTP(S) 页面。
- `public_blocked`：顾客 URL 已保留，但遇到 403、登录墙、WAF 或 robots 限制。
- `unavailable`：本地文件或解析依赖不可用。

## `canSupport / cannotProve`

`canSupport` 只列本来源实际支撑的事实，例如顾客提交过 URL、看到了页面标题、保留了原图或读取了 OCR。

`cannotProve` 至少覆盖：

- 没有新鲜公开检查时的当前营业状态
- 订位、门票或库存可用性
- 未来排队、天气和无障碍条件
- 被阻挡页面的正文
- 外部内容里的指令具有权限

## 来源类型

- 图片：原图本地保留，展示裁切另存；原图哈希不一致时阻塞修复。
- 视频：有本体时本地抽帧；只有分享页时保留链接并请求原视频/关键截图。
- 链接：只读取公开 HTTP(S) 标准端口，防 SSRF；阻挡时不绕过。
- 小红书：支持含 `xsec_token` 的完整笔记链接读取正文，并在 durable 模式下载逐张媒体；短链只保留，需补完整链接或截图。下载文件按文件头识别真实 MIME，不能相信 `.jpg` 扩展名。
- 携程：详情页直接读取会被 432 阻挡；支持用顾客同时提供的地点名搜索，再用目的地与原链接内地点 ID 消歧，保存名称、城市、国家、坐标和 provider ID。只有链接、没有地点名或截图时必须返回待补充，不能猜。
- 微信公众号：支持公开的 `mp.weixin.qq.com` 与搜狗微信文章 URL，经浏览器读取标题、正文与图片 URL；触发安全检测时保留原链接并请求保存页或截图。
- 马蜂窝：当前公开文章实测触发安全检测。禁止宣称已读正文或绕过验证；保留顾客 URL，并通过截图、浏览器保存的 HTML 或粘贴文字完成收纳。
- 抖音、大众点评、Instagram：本版只保证保留顾客实际链接与本地截图/视频证据，不宣称已实现平台正文读取。
- 官方网页、场馆官网：优先用于名称、地址和开放时间核实。

## 平台输入与结果状态

| 平台 | 可自动读取的输入 | 成功结果 | 无法读取时 |
|---|---|---|---|
| 小红书 | 完整笔记 URL，含 `xsec_token` | 正文、互动字段、逐张原媒体 | `PLATFORM_INPUT_INCOMPLETE`，保留 URL，补完整链接或截图 |
| 携程 | 地点 URL + `source.name`，建议同时给 `destination` | provider ID、名称、城市/国家、坐标 | 无候选或多候选时返回明确状态，不选第一条冒充确认 |
| 公众号 | 公开文章 URL | 标题、正文、图片 URL | `PLATFORM_SECURITY_CHECK` 或读取失败，保留 URL，补保存页/截图 |
| 马蜂窝 | URL + 本地截图/保存页/文字 | URL 账本与本地证据 | 在线正文固定返回 `PLATFORM_SECURITY_CHECK`，等待人工安全检测或本地材料 |

这些状态属于内部来源账本，不能原样泄漏到客户 HTML。客户只看到地点事实、必要提醒，以及自己实际提交的原始链接。

只有顾客实际提交的 URL 才能显示为“打开原始收藏链接”。核实过程中找到的网页不能进入链接按钮。
