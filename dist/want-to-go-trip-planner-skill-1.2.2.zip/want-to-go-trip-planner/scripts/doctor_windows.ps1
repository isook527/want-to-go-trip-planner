$ErrorActionPreference = "Stop"

function Test-Executable([string]$Name) {
    return $null -ne (Get-Command $Name -ErrorAction SilentlyContinue)
}

$pythonName = $null
$pythonPrefix = @()

if (Test-Executable "py") {
    & py -3 --version *> $null
    if ($LASTEXITCODE -eq 0) {
        $pythonName = "py"
        $pythonPrefix = @("-3")
    }
}

if ($null -eq $pythonName -and (Test-Executable "python")) {
    & python --version *> $null
    if ($LASTEXITCODE -eq 0) {
        $pythonName = "python"
    }
}

if ($null -eq $pythonName -and (Test-Executable "python3")) {
    & python3 --version *> $null
    if ($LASTEXITCODE -eq 0) {
        $pythonName = "python3"
    }
}

if ($null -eq $pythonName) {
    $result = [ordered]@{
        schemaVersion = "kornvia-install-doctor-1.2.2"
        platform = [ordered]@{
            name = "Windows"
            supported = $true
        }
        status = "blocked"
        coreReady = $false
        fullReady = $false
        dependencies = [ordered]@{
            python = [ordered]@{ installed = $false; ready = $false; minimum = "3.9" }
            node = [ordered]@{ installed = (Test-Executable "node") }
            tesseract = [ordered]@{ installed = (Test-Executable "tesseract") }
            ffmpeg = [ordered]@{ installed = (Test-Executable "ffmpeg") }
            ffprobe = [ordered]@{ installed = (Test-Executable "ffprobe") }
        }
        blockingIssues = @("缺少 Python 3.9 或更高版本，无法启动想去库安装检测。")
        featureWarnings = @()
        installCommands = @("winget install --id Python.Python.3.12 -e")
    }
    $result | ConvertTo-Json -Depth 6
    exit 2
}

$doctorPath = Join-Path $PSScriptRoot "extract_evidence.py"
$arguments = @()
$arguments += $pythonPrefix
$arguments += @($doctorPath, "doctor", "--locale", "zh-CN")
& $pythonName @arguments
exit $LASTEXITCODE
